# Bot module for AI chatbot functionality
from flask import Blueprint
from app.bot.routes import bot_bp

__all__ = ['bot_bp']

